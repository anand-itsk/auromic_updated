<?php

namespace App\Http\Controllers\PageControllers\Report;

use App\Http\Controllers\Controller;
use App\Models\Company;
use App\Models\Employee;
use App\Models\JobReceived;
use Illuminate\Http\Request;
use Yajra\DataTables\DataTables;

class TotalWagesReport extends Controller
{
    public function index()
    {
        $employee = Employee::all();

        $masterCompany = Company::where('company_type_id', 2)->get();
        $clientCompany = Company::where('company_type_id', 3)->get();
        $subClientCompany = Company::where('company_type_id', 4)->get();


        return view('pages.report.total_wages', compact('employee', 'masterCompany', 'clientCompany', 'subClientCompany'));
    }

    public function indexData()
    {
        // Fetch the job_received data along with relationships
        $job_received = JobReceived::with(['jobGiving.employee.company'])
            ->get();

        return DataTables::of($job_received)
            // Add a column for the company name
            ->addColumn('company_name', function ($row) {
                return $row->jobGiving->employee->company->company_name ?? 'N/A';
            })
            // Add a column for total complete_quantity based on job_giving_id
            ->addColumn('total_complete_quantity', function ($row) {
                // Get the job_giving_id of the current row
                $job_giving_id = $row->job_giving_id;

                // Calculate the total complete_quantity for this job_giving_id
                $total_complete_quantity = JobReceived::where('job_giving_id', $job_giving_id)
                    ->sum('complete_quantity');

                return $total_complete_quantity ?? 'N/A';
            })
            ->make(true);
    }




}
