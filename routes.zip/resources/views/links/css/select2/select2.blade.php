<link href="https://cdnjs.cloudflare.com/ajax/libs/select2/4.0.13/css/select2.min.css" rel="stylesheet" />
<style>
    .select2{
        width: 100% !important;
    }
    .select2-container--default .select2-selection--single {
        border: 1px solid #ced4da;
        line-height: 2.5;
    }

    .select2-container .select2-selection--single {
        height: calc(1.5em + 0.75rem + 2px);
    }
    .select2-container--default .select2-selection--single .select2-selection__rendered{
        line-height: unset;
    }
</style>
